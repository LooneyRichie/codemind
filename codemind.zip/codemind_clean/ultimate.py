#!/usr/bin/env python3
"""
CodeMind Ultimate - One script to rule them all!
Perfect for Termux - No complex setup required!
"""

import os
import sys
import json
import subprocess
import argparse
from pathlib import Path

class CodeMindUltimate:
    def __init__(self):
        self.config_file = Path.home() / '.codemind_config.json'
        self.config = self.load_config()
        self.first_run_setup()
    
    def load_config(self):
        """Load or create configuration"""
        default_config = {
            "provider": "offline",  # Start with offline for Termux compatibility
            "openai_api_key": "",
            "groq_api_key": "",  # Free alternative to OpenAI
            "setup_complete": False,
            "termux_mode": self.is_termux()
        }
        
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    # Merge with defaults
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    return config
            except:
                pass
        
        self.save_config(default_config)
        return default_config
    
    def save_config(self, config=None):
        """Save configuration"""
        if config is None:
            config = self.config
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
        except:
            pass
    
    def is_termux(self):
        """Check if running in Termux"""
        return 'com.termux' in os.environ.get('PREFIX', '') or '/data/data/com.termux' in os.environ.get('HOME', '')
    
    def first_run_setup(self):
        """Interactive first-run setup"""
        if not self.config.get('setup_complete', False):
            self.welcome_message()
            self.interactive_setup()
    
    def welcome_message(self):
        """Show welcome message"""
        print("🧠 Welcome to CodeMind Ultimate!")
        print("=" * 50)
        if self.config['termux_mode']:
            print("📱 Termux detected - Using mobile-optimized setup")
        print("🚀 Let's get you set up in 30 seconds...")
        print()
    
    def interactive_setup(self):
        """Simple interactive setup"""
        print("Choose your preferred mode:")
        print("1. 🔒 Offline Mode (No internet, instant responses)")
        print("2. 🌐 Cloud API Mode (Better AI, needs internet)")
        print("3. ⚡ Both (Offline + Cloud when available)")
        print()
        
        choice = input("Enter your choice (1-3) [1]: ").strip() or "1"
        
        if choice == "1":
            self.config['provider'] = 'offline'
            print("✅ Offline mode selected - You're ready to go!")
        
        elif choice == "2":
            self.setup_cloud_api()
        
        elif choice == "3":
            self.config['provider'] = 'auto'
            self.setup_cloud_api(optional=True)
        
        else:
            self.config['provider'] = 'offline'
            print("✅ Defaulting to offline mode")
        
        self.config['setup_complete'] = True
        self.save_config()
        print("\n🎉 Setup complete! Type 'help' to see what you can do.")
        print()
    
    def setup_cloud_api(self, optional=False):
        """Setup cloud API with free options"""
        print("\n🌐 Cloud API Setup")
        print("Choose a free/cheap API option:")
        print("1. 🆓 Groq (Free tier available)")
        print("2. 💰 OpenAI (Paid, but high quality)")
        print("3. ⏭️  Skip for now" + (" (use offline mode)" if optional else ""))
        
        api_choice = input("Enter choice (1-3) [1]: ").strip() or "1"
        
        if api_choice == "1":
            print("\n📝 Get your FREE Groq API key:")
            print("1. Go to: https://console.groq.com/")
            print("2. Sign up (it's free!)")
            print("3. Go to API Keys section")
            print("4. Create a new API key")
            print()
            
            api_key = input("Paste your Groq API key (or press Enter to skip): ").strip()
            if api_key:
                self.config['groq_api_key'] = api_key
                self.config['provider'] = 'groq'
                print("✅ Groq API configured!")
            elif not optional:
                self.config['provider'] = 'offline'
                print("⚠️  No API key provided, using offline mode")
        
        elif api_choice == "2":
            print("\n💰 OpenAI Setup:")
            print("1. Go to: https://platform.openai.com/")
            print("2. Create account and add billing")
            print("3. Generate API key")
            print()
            
            api_key = input("Paste your OpenAI API key (or press Enter to skip): ").strip()
            if api_key:
                self.config['openai_api_key'] = api_key
                self.config['provider'] = 'openai'
                print("✅ OpenAI API configured!")
            elif not optional:
                self.config['provider'] = 'offline'
                print("⚠️  No API key provided, using offline mode")
        
        else:
            if not optional:
                self.config['provider'] = 'offline'
            print("⏭️  Skipping cloud setup")
    
    def query_groq(self, prompt):
        """Query Groq API (free alternative)"""
        try:
            import requests
            
            headers = {
                'Authorization': f'Bearer {self.config["groq_api_key"]}',
                'Content-Type': 'application/json'
            }
            
            data = {
                'messages': [
                    {'role': 'system', 'content': 'You are a helpful coding assistant for terminal/CLI usage. Be concise and practical.'},
                    {'role': 'user', 'content': prompt}
                ],
                'model': 'mixtral-8x7b-32768',  # Free tier model
                'temperature': 0.2,
                'max_tokens': 500
            }
            
            response = requests.post('https://api.groq.com/openai/v1/chat/completions', 
                                   headers=headers, json=data, timeout=10)
            
            if response.status_code == 200:
                return response.json()['choices'][0]['message']['content'].strip()
            else:
                return f"API Error: {response.status_code}"
                
        except ImportError:
            self.install_requests()
            return self.query_groq(prompt)  # Retry after install
        except Exception as e:
            return f"Error: {str(e)}"
    
    def query_openai(self, prompt):
        """Query OpenAI API"""
        try:
            import requests
            
            headers = {
                'Authorization': f'Bearer {self.config["openai_api_key"]}',
                'Content-Type': 'application/json'
            }
            
            data = {
                'messages': [
                    {'role': 'system', 'content': 'You are a helpful coding assistant for terminal/CLI usage. Be concise and practical.'},
                    {'role': 'user', 'content': prompt}
                ],
                'model': 'gpt-3.5-turbo',
                'temperature': 0.2,
                'max_tokens': 500
            }
            
            response = requests.post('https://api.openai.com/v1/chat/completions', 
                                   headers=headers, json=data, timeout=10)
            
            if response.status_code == 200:
                return response.json()['choices'][0]['message']['content'].strip()
            else:
                return f"API Error: {response.status_code}"
                
        except ImportError:
            self.install_requests()
            return self.query_openai(prompt)  # Retry after install
        except Exception as e:
            return f"Error: {str(e)}"
    
    def install_requests(self):
        """Auto-install requests if needed"""
        try:
            print("📦 Installing required package...")
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'requests'])
            print("✅ Package installed!")
        except:
            print("❌ Failed to install requests. Please run: pip install requests")
    
    def query_offline(self, prompt_type, text):
        """Offline command database"""
        if prompt_type == "generate":
            return self.generate_command_offline(text)
        elif prompt_type == "explain":
            return self.explain_command_offline(text)
        else:
            return self.general_help_offline(text)
    
    def generate_command_offline(self, description):
        """Generate command from description - offline mode"""
        desc = description.lower()
        
        # File operations
        if "find" in desc and "large" in desc:
            return "find . -size +100M -type f"
        elif "find" in desc and "recent" in desc:
            return "find . -mtime -1 -type f"
        elif "find" in desc and ("python" in desc or ".py" in desc):
            return "find . -name '*.py' -type f"
        elif "find" in desc and "empty" in desc:
            return "find . -empty -type f"
        elif "count" in desc and "lines" in desc:
            return "wc -l filename"
        elif "disk" in desc and "usage" in desc:
            return "du -h --max-depth=1 | sort -hr"
        elif "disk" in desc and "space" in desc:
            return "df -h"
        
        # Process management
        elif "memory" in desc and "usage" in desc:
            return "free -h"
        elif "process" in desc and "memory" in desc:
            return "ps aux --sort=-%mem | head -10"
        elif "process" in desc and "cpu" in desc:
            return "ps aux --sort=-%cpu | head -10"
        elif "kill" in desc and "process" in desc:
            return "pkill -f process_name"
        elif "running" in desc and "process" in desc:
            return "ps aux"
        
        # Text operations
        elif "search" in desc and "file" in desc:
            return "grep -r 'pattern' ."
        elif "replace" in desc and "text" in desc:
            return "sed -i 's/old/new/g' filename"
        elif "count" in desc and "word" in desc:
            return "wc -w filename"
        
        # Network
        elif "download" in desc:
            return "wget URL"
        elif "curl" in desc or "http" in desc:
            return "curl -X GET URL"
        elif "ping" in desc:
            return "ping -c 4 hostname"
        
        # Archives
        elif "extract" in desc and ("tar" in desc or "gz" in desc):
            return "tar -xzf archive.tar.gz"
        elif "create" in desc and ("tar" in desc or "archive" in desc):
            return "tar -czf archive.tar.gz folder/"
        elif "zip" in desc and "create" in desc:
            return "zip -r archive.zip folder/"
        elif "unzip" in desc or ("extract" in desc and "zip" in desc):
            return "unzip archive.zip"
        
        # Git operations
        elif "git" in desc and "status" in desc:
            return "git status"
        elif "git" in desc and "commit" in desc:
            return "git add . && git commit -m 'message'"
        elif "git" in desc and "push" in desc:
            return "git push origin main"
        elif "git" in desc and "pull" in desc:
            return "git pull origin main"
        
        # System info
        elif "system" in desc and "info" in desc:
            return "uname -a"
        elif "cpu" in desc and "info" in desc:
            return "cat /proc/cpuinfo"
        elif "uptime" in desc:
            return "uptime"
        
        else:
            return f"# No exact match found for '{description}'\n# Try: 'list all files', 'show memory usage', 'find large files'"
    
    def explain_command_offline(self, command):
        """Explain command - offline mode"""
        cmd_parts = command.split()
        if not cmd_parts:
            return "No command provided"
        
        main_cmd = cmd_parts[0]
        
        explanations = {
            "ls": "List directory contents",
            "cd": "Change directory", 
            "pwd": "Print working directory",
            "mkdir": "Create directory",
            "rm": "Remove files/directories",
            "cp": "Copy files/directories",
            "mv": "Move/rename files/directories",
            "cat": "Display file contents",
            "grep": "Search text patterns in files",
            "find": "Search for files and directories",
            "ps": "Show running processes",
            "kill": "Terminate processes",
            "chmod": "Change file permissions",
            "du": "Show disk usage",
            "df": "Show filesystem disk space",
            "tar": "Archive files",
            "wget": "Download files from web",
            "curl": "Transfer data from servers",
            "git": "Version control system",
            "ssh": "Secure shell remote login",
            "ping": "Test network connectivity"
        }
        
        base_explanation = explanations.get(main_cmd, f"'{main_cmd}' - Use 'man {main_cmd}' for detailed help")
        
        # Add common flag explanations
        flags = []
        if "-l" in command: flags.append("-l: long format")
        if "-a" in command: flags.append("-a: show hidden files")
        if "-r" in command: flags.append("-r: recursive")
        if "-f" in command: flags.append("-f: force")
        if "-v" in command: flags.append("-v: verbose")
        if "-h" in command: flags.append("-h: human readable")
        
        if flags:
            return f"{base_explanation}. Flags: {', '.join(flags)}"
        return base_explanation
    
    def general_help_offline(self, question):
        """General help - offline mode"""
        q = question.lower()
        
        if "python" in q and "virtual" in q:
            return "Create Python virtual environment:\npython -m venv myenv\nsource myenv/bin/activate  # (or myenv\\Scripts\\activate on Windows)"
        elif "git" in q and "clone" in q:
            return "Clone a git repository:\ngit clone https://github.com/user/repo.git"
        elif "permission" in q and "denied" in q:
            return "Fix permission denied:\n1. Use 'sudo' for admin access\n2. Change permissions with 'chmod +x filename'\n3. Check file ownership with 'ls -la'"
        elif "ssh" in q:
            return "SSH connection:\nssh username@hostname\n\nGenerate SSH key:\nssh-keygen -t ed25519 -C 'your@email.com'"
        elif "port" in q:
            return "Check port usage:\nnetstat -tuln | grep :PORT\n\nOr with lsof:\nlsof -i :PORT"
        else:
            return f"For '{question}', try:\n• man command_name (for command help)\n• command_name --help\n• Use specific keywords like 'find files', 'show processes', etc."
    
    def query_ai(self, prompt_type, text):
        """Route to appropriate AI provider"""
        provider = self.config.get('provider', 'offline')
        
        # Auto mode: try cloud first, fallback to offline
        if provider == 'auto':
            if self.config.get('groq_api_key'):
                result = self.query_groq(self.build_prompt(prompt_type, text))
                if not result.startswith('Error'):
                    return result
            elif self.config.get('openai_api_key'):
                result = self.query_openai(self.build_prompt(prompt_type, text))
                if not result.startswith('Error'):
                    return result
            # Fallback to offline
            return self.query_offline(prompt_type, text)
        
        elif provider == 'groq' and self.config.get('groq_api_key'):
            return self.query_groq(self.build_prompt(prompt_type, text))
        
        elif provider == 'openai' and self.config.get('openai_api_key'):
            return self.query_openai(self.build_prompt(prompt_type, text))
        
        else:
            return self.query_offline(prompt_type, text)
    
    def build_prompt(self, prompt_type, text):
        """Build appropriate prompt for AI"""
        if prompt_type == "generate":
            return f"Generate a command-line command for: {text}\n\nRules:\n1. Return ONLY the command, no explanations\n2. Make it work on Linux/Termux\n3. Use common utilities\n\nCommand:"
        elif prompt_type == "explain":
            return f"Explain this command in simple terms: {text}"
        elif prompt_type == "fix":
            return f"Fix this broken command: {text}"
        else:
            return text
    
    def interactive_mode(self):
        """Interactive chat mode"""
        print("🧠 CodeMind Interactive Mode")
        print(f"Mode: {self.config['provider'].title()}")
        if self.config['termux_mode']:
            print("📱 Termux optimized")
        print("Type 'help' for commands, 'exit' to quit")
        print("-" * 40)
        
        while True:
            try:
                user_input = input("\n🧠 > ").strip()
                
                if user_input.lower() in ['exit', 'quit', 'q']:
                    print("👋 Goodbye!")
                    break
                
                elif user_input.lower() in ['help', 'h']:
                    self.show_interactive_help()
                
                elif user_input.startswith('cmd:') or user_input.startswith('generate:'):
                    description = user_input.split(':', 1)[1].strip()
                    result = self.query_ai("generate", description)
                    print(f"💡 {result}")
                
                elif user_input.startswith('explain:'):
                    command = user_input.split(':', 1)[1].strip()
                    result = self.query_ai("explain", command)
                    print(f"📖 {result}")
                
                elif user_input.startswith('fix:'):
                    command = user_input.split(':', 1)[1].strip()
                    result = self.query_ai("fix", command)
                    print(f"🔧 {result}")
                
                elif user_input.lower() == 'setup':
                    self.config['setup_complete'] = False
                    self.interactive_setup()
                
                elif user_input.lower() == 'status':
                    self.show_status()
                
                else:
                    result = self.query_ai("general", user_input)
                    print(f"🤖 {result}")
                    
            except KeyboardInterrupt:
                print("\n👋 Goodbye!")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
    
    def show_interactive_help(self):
        """Show interactive help"""
        print("""
🧠 CodeMind Commands:

📝 Generate Commands:
  cmd: find large files
  generate: show memory usage
  
📖 Explain Commands:  
  explain: ls -la
  explain: grep -r pattern .
  
🔧 Fix Commands:
  fix: broken command here
  
❓ Ask Questions:
  How do I create a Python virtual environment?
  What does chmod +x do?
  
⚙️  System:
  setup   - Re-run setup
  status  - Show current configuration  
  help    - Show this help
  exit    - Quit
        """)
    
    def show_status(self):
        """Show current status"""
        print(f"\n📊 CodeMind Status:")
        print(f"Mode: {self.config['provider'].title()}")
        print(f"Termux: {'Yes' if self.config['termux_mode'] else 'No'}")
        if self.config.get('groq_api_key'):
            print("Groq API: ✅ Configured")
        if self.config.get('openai_api_key'):
            print("OpenAI API: ✅ Configured")
        print(f"Config: {self.config_file}")
    
    def run_command(self, command, *args):
        """Run specific command"""
        if command == "generate":
            if args:
                result = self.query_ai("generate", " ".join(args))
                print(result)
            else:
                print("Usage: generate <description>")
        
        elif command == "explain":
            if args:
                result = self.query_ai("explain", " ".join(args))
                print(result)
            else:
                print("Usage: explain <command>")
        
        elif command == "ask":
            if args:
                result = self.query_ai("general", " ".join(args))
                print(result)
            else:
                print("Usage: ask <question>")
        
        elif command == "setup":
            self.config['setup_complete'] = False
            self.interactive_setup()
        
        elif command == "status":
            self.show_status()
        
        elif command == "interactive":
            self.interactive_mode()
        
        else:
            print(f"Unknown command: {command}")
            print("Available: generate, explain, ask, setup, status, interactive")

def main():
    """Main entry point"""
    codemind = CodeMindUltimate()
    
    if len(sys.argv) == 1:
        # No arguments - start interactive mode
        codemind.interactive_mode()
    else:
        # Command line arguments
        command = sys.argv[1]
        args = sys.argv[2:]
        codemind.run_command(command, *args)

if __name__ == "__main__":
    main()
