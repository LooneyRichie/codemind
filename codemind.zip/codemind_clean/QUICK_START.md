# 🧠 CodeMind - Clean & Simple

## Quick Start (30 seconds!)

### 1. Setup (run once):
```bash
./setup.sh
```

### 2. Use:
```bash
# Interactive AI chat
./codemind

# Quick commands
python3 ultimate.py generate "find large files"
python3 offline_helper.py explain "ls -la"
```

## What You Have:
- `ultimate.py` - Full AI assistant (offline + cloud)
- `offline_helper.py` - Fast command database  
- `codemind.py` - AI code commenter
- `codemind` - Simple launcher
- `setup.sh` - One-click installer

## That's It!
No confusion, no extra files. Just 5 essential tools.

Happy coding! 🚀
