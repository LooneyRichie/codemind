#!/usr/bin/env python3
import argparse
import os
from openai import OpenAI

# Get API key from environment variable for security
api_key = os.getenv("OPENAI_API_KEY")

if not api_key:
    print("Error: OPENAI_API_KEY environment variable not set.")
    print("Please set it with: export OPENAI_API_KEY='your-api-key-here'")
    exit(1)

# Initialize OpenAI client
client = OpenAI(api_key=api_key)

def get_comment_response(code, language="python", style="technical"):
    prompt = f"""You are an expert code explainer. Read the following {language} code and generate a well-formatted comment block with correct syntax and indentation, in a {style} tone.

Code:
{code}

Return only the comments, do not repeat or reformat the original code.
"""
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You're a helpful assistant for developers."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.2
    )
    return response.choices[0].message.content.strip()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AI-powered code commenting tool")
    parser.add_argument("--file", help="Path to code file", required=True)
    parser.add_argument("--range", help="Line range to comment (e.g., 10:20)", default="")
    parser.add_argument("--language", help="Language of the code", default="python")
    parser.add_argument("--style", help="Comment style: technical | casual | inline", default="technical")
    args = parser.parse_args()

    # Check if file exists
    if not os.path.exists(args.file):
        print(f"Error: File '{args.file}' not found.")
        exit(1)

    with open(args.file, "r") as f:
        lines = f.readlines()

    if args.range:
        start, end = map(int, args.range.split(":"))
        code_segment = "".join(lines[start-1:end])
    else:
        code_segment = "".join(lines)

    comments = get_comment_response(code_segment, language=args.language, style=args.style)
    print(comments)
    with open(args.file, "a") as f:
        f.write("\n# AI-generated comments:\n")
        f.write(comments + "\n")
    print("Comments added to the file.")
    print("Run the script with --help for usage instructions.")
    print("Ensure you have set the OPENAI_API_KEY environment variable.")
    print("Example usage: python comment_code.py --file your_code.py --range 10:20 --language python --style technical")
    print("You can also specify the language and style of comments.")