#!/usr/bin/env python3
"""
CodeMind Offline Helper - no internet required
"""

import sys
import re

class CodeMindOffline:
    def __init__(self):
        self.commands = {
            # File operations
            "find files": "find . -name '*pattern*' -type f",
            "find large files": "find . -size +100M -type f",
            "find recent files": "find . -mtime -1 -type f",
            "count lines": "wc -l filename",
            "disk usage": "du -h --max-depth=1 | sort -hr",
            "show permissions": "ls -la",
            
            # Text processing
            "search in files": "grep -r 'pattern' .",
            "search case insensitive": "grep -ri 'pattern' .",
            "count occurrences": "grep -c 'pattern' filename",
            "replace text": "sed -i 's/old/new/g' filename",
            
            # System info
            "show processes": "ps aux",
            "memory usage": "free -h",
            "cpu info": "cat /proc/cpuinfo",
            "disk space": "df -h",
            "network connections": "netstat -tuln",
            
            # Archives
            "create tar": "tar -czf archive.tar.gz folder/",
            "extract tar": "tar -xzf archive.tar.gz",
            "create zip": "zip -r archive.zip folder/",
            "extract zip": "unzip archive.zip",
            
            # Process management
            "kill process": "pkill -f process_name",
            "background job": "nohup command &",
            "list running jobs": "jobs",
            
            # Network
            "download file": "wget URL",
            "curl get": "curl -X GET URL",
            "ping host": "ping -c 4 hostname",
            "check port": "nc -zv hostname port",
        }
        
        self.explanations = {
            "ls -la": "List files with detailed info including hidden files and permissions",
            "grep -r": "Search recursively through all files in directory",
            "find . -name": "Search for files by name pattern starting from current directory",
            "du -h": "Show disk usage in human readable format",
            "ps aux": "Show all running processes with detailed information",
            "chmod +x": "Make file executable",
            "tar -czf": "Create compressed tar archive",
            "tar -xzf": "Extract compressed tar archive",
            "sudo": "Run command with administrator privileges",
            "ssh": "Secure shell connection to remote server",
            "scp": "Secure copy files over network",
            "curl": "Transfer data from/to servers",
            "wget": "Download files from web",
            "tail -f": "Follow/watch file changes in real time",
            "head -n": "Show first N lines of file",
            "wc -l": "Count lines in file",
        }
    
    def find_command(self, description):
        """Find best matching command"""
        description = description.lower()
        
        # Direct matches
        for key, cmd in self.commands.items():
            if key in description:
                return cmd
        
        # Keyword matching
        if "find" in description and "large" in description:
            return "find . -size +100M -type f"
        elif "find" in description and "recent" in description:
            return "find . -mtime -1 -type f"
        elif "search" in description:
            return "grep -r 'pattern' ."
        elif "memory" in description:
            return "free -h"
        elif "process" in description:
            return "ps aux"
        elif "disk" in description:
            return "df -h"
        elif "kill" in description:
            return "pkill -f process_name"
        
        return "# No matching command found. Try being more specific."
    
    def explain_command(self, command):
        """Explain a command"""
        cmd_parts = command.split()
        if not cmd_parts:
            return "No command provided"
        
        main_cmd = cmd_parts[0]
        
        # Check for exact matches first
        for pattern, explanation in self.explanations.items():
            if pattern in command:
                return explanation
        
        # Basic explanations for common commands
        explanations = {
            "ls": "List directory contents",
            "cd": "Change directory",
            "pwd": "Print working directory",
            "mkdir": "Create directory",
            "rmdir": "Remove empty directory",
            "rm": "Remove files/directories",
            "cp": "Copy files/directories",
            "mv": "Move/rename files/directories",
            "cat": "Display file contents",
            "less": "View file contents page by page",
            "more": "View file contents page by page",
            "head": "Show first lines of file",
            "tail": "Show last lines of file",
            "grep": "Search text patterns in files",
            "find": "Search for files and directories",
            "locate": "Find files by name",
            "which": "Show location of command",
            "ps": "Show running processes",
            "top": "Show processes and system usage",
            "htop": "Interactive process viewer",
            "kill": "Terminate processes",
            "killall": "Kill processes by name",
            "chmod": "Change file permissions",
            "chown": "Change file ownership",
            "du": "Show disk usage",
            "df": "Show filesystem disk space",
            "mount": "Mount filesystems",
            "umount": "Unmount filesystems",
            "tar": "Archive files",
            "gzip": "Compress files",
            "gunzip": "Decompress files",
            "zip": "Create ZIP archives",
            "unzip": "Extract ZIP archives",
            "ssh": "Secure shell remote login",
            "scp": "Secure copy over network",
            "rsync": "Synchronize files/directories",
            "curl": "Transfer data from servers",
            "wget": "Download files from web",
            "ping": "Test network connectivity",
            "netstat": "Show network connections",
            "iptables": "Configure firewall rules",
            "systemctl": "Control systemd services",
            "service": "Control system services",
            "crontab": "Schedule tasks",
            "history": "Show command history",
            "alias": "Create command shortcuts",
            "export": "Set environment variables",
            "env": "Show environment variables",
            "echo": "Display text",
            "printf": "Formatted text output",
            "date": "Show/set system date",
            "cal": "Show calendar",
            "bc": "Calculator",
            "man": "Show manual pages",
            "info": "Show info documents",
            "help": "Show command help",
        }
        
        if main_cmd in explanations:
            base_explanation = explanations[main_cmd]
            
            # Add flag explanations
            flag_info = []
            if "-l" in command:
                flag_info.append("-l: long format")
            if "-a" in command:
                flag_info.append("-a: show hidden files")
            if "-r" in command:
                flag_info.append("-r: recursive")
            if "-f" in command:
                flag_info.append("-f: force")
            if "-v" in command:
                flag_info.append("-v: verbose")
            if "-h" in command:
                flag_info.append("-h: human readable")
            
            if flag_info:
                return f"{base_explanation}. Flags: {', '.join(flag_info)}"
            else:
                return base_explanation
        
        return f"'{main_cmd}' - Command not in database. Use 'man {main_cmd}' for help."

def main():
    helper = CodeMindOffline()
    
    if len(sys.argv) < 2:
        print("� CodeMind Offline Helper")
        print("Usage:")
        print("  codemind-offline generate 'description'")
        print("  codemind-offline explain 'command'")
        print()
        print("Examples:")
        print("  codemind-offline generate 'find large files'")
        print("  codemind-offline explain 'ls -la'")
        return
    
    action = sys.argv[1].lower()
    
    if action == "generate" and len(sys.argv) >= 3:
        description = " ".join(sys.argv[2:])
        result = helper.find_command(description)
        print(result)
    
    elif action == "explain" and len(sys.argv) >= 3:
        command = " ".join(sys.argv[2:])
        result = helper.explain_command(command)
        print(result)
    
    else:
        print("Usage: codemind-offline [generate|explain] 'text'")

if __name__ == "__main__":
    main()
