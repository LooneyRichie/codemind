#!/bin/bash
# Simple CodeMind installer for Termux

echo "🧠 Setting up CodeMind..."

# Install Python if needed
if ! command -v python3 &> /dev/null; then
    echo "📦 Installing Python..."
    pkg update && pkg install python -y
fi

# Install requests for cloud features (optional)
pip install requests 2>/dev/null || echo "⚠️  Could not install requests (offline mode will still work)"

# Make scripts executable
chmod +x ultimate.py offline_helper.py codemind

echo "✅ Setup complete!"
echo ""
echo "🚀 Try these commands:"
echo "   ./codemind                              # Interactive AI chat"
echo "   python3 ultimate.py generate "find large files""
echo "   python3 offline_helper.py generate "show memory usage""
echo ""
echo "📱 Works perfectly on Termux!"
